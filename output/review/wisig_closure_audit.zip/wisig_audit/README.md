# Portable WiSig closure audit

This bundle contains the full W1/W2 paired intervals, receiver/TX risk tables,
frozen selected prediction arrays, pairing/trajectory summaries, and prior P2/F2/M1
STOP summaries. No raw IQ or model/optimizer weights are included.

Requirements: Python 3.10+ and NumPy. From quality_preservation/ run:

    python verify_results.py

Expected result: PASS 175 checks. The verifier has no absolute-D-path dependency.
It recomputes statistical summaries and checks recorded orders/pairings; it does
not independently reproduce neural training, infer physical causality, or make
the development receivers new blind tests. Absolute paths in historical metadata
are retained as provenance and are not dereferenced by this verifier.

Prior STOP folders contain historical decision/report snapshots only; the full
portable statistical replay is specific to W1/W2. Do not invoke the one-shot
training scripts to inspect these results. Their original inputs are intentionally
not bundled. Every bundled input is pinned by SHA256SUMS.json.
